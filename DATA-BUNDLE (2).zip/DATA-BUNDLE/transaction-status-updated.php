<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data bundle status</title>
    <style>
    body{
        background-color: grey;
        color: white
    }
</style>
</head>
<body><center>
<a href="index.php"><H1><H1>Go home</H1></H1></a> <a href="https://google.com" style="color:white"><h1><h1>EXIT</h1></h1></a>

<div class="card shadow mb-5 p-3">
                            <div class="title"><h2 style="color: white;"> STATUS OF ORDERS</h2></div>
                            <div class="card-title">
                                <div class="alert alert-info">
                                    <STRONG style="background-color: white; color: black"><em>...Below is the status of your order...</em> </STRONG>
                                </div>
                            </div>
                            
                            <BR></BR>
                            <div class="alert alert-info">
                                    <STRONG style="background-color: white; color: black"></STRONG>
                                </div>
                                <strong><em><h2 style="background color: black; color: white;">8:00AM-7:15PM</h2></em></strong><p>
<strong><em><h2 style="background color: black; color: white;">DO NOT SEND MTN ORDERS AT 7:15PM</h2></em></strong>
                             
                            <TAble>
                            <tr>
                                <th>Recipient</th>
                                <th>data</th>
                                <th>status</th>
                                
                            </tr>
<strong><em><h2 style="background color: black; color: white;">DO NOT SEND MTN ORDERS AT 7:15PM</h2></em></strong>

                            </table>

                            <table>
<tr>
<th>0542733502
    <th>2gb
        <th>delivered
            <th>

            </th>
        </th>
    </th>
</th>
</tr>
</tr>
<tr>
<th>0549456395
    <th>2gb
        <th>delivered
                
            </th>
        </th>
    </th>
</th>
</tr>
</tr>
<tr>
<th>0549411336
    <th>5gb
        <th>delivered
                
            </th>
        </th>
    </th>
</th>
</tr>

<TR>
    <TH>0595014342
        <TH>1gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>

<TR>
    <TH>0248425602
        <TH>1gb
            <TH>delivered

            </TH>
        </TH>
    </TH>
</TR>
</tr>
<tr>
<th>0266969647
    <th>20gb
        <th>delivered
        </th>
    </th>
</th>
</tr>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>0592196453
    <th>2gb
        <th>delivered
        </th>
    </th>
</th>
</tr>

<tr>
<th>0244509280
    <th>20gb
        <th>delivered
        </th>
    </th>
</th>
</tr>


<tr>
<th>0597349171
    <th>2gb
        <th>delivered
        </th>
    </th>
</th>
</tr>
<tr>
<th>0555225606
    <th>5gb
        <th>delivered
        </th>
    </th>
</th>
</tr>
<tr>
<th>0246207342
    <th>8gb
        <th>delivered
        </th>
    </th>
</th>
</tr>
<tr>
<th>0547076598
    <th>3gb
        <th>delivered
        </th>
    </th>
</th>
</tr>
<tr>
<th>0546673405 
    <th>10gb
        <th>delivering
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>

</table>
<strong><em><h2 style="background color: black; color: white;">29/05/2023</h2></em></strong>
<table>
<tr>
<th>
    <th>
        
        </th>
    </th>
</th>
</tr>
</table>
<table>
<tr>
    <th>0551837446 
        <th>15gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>     
<tr>
    <th>0593358550
        <th>10gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>  
<TR>
    <TH>0595014342
        <TH>1gb
            <TH>delivered

            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0558602063
        <TH>6gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0597650764
        <TH>20gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>

<TR>
    <TH>0550498464
        <TH>2gb
            <TH>delivered

            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0540356437
        <TH>10gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0257575052
        <TH>3gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>

<TR>
    <TH>0541490668
        <TH>1gb
            <TH>delivered

            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0547987679
        <TH>3gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0549779482
        <TH>12gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>

<TR>
    <TH>0256979417
        <TH>2gb
            <TH>delivered

            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0245504923
        <TH>1gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0546091843
        <TH>10gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>
<TR>
    <TH>0547076598
        <TH>3gb
            <TH>delivered
                
            </TH>
        </TH>
    </TH>
</TR>
<tr>
    <th>0595014342
        <th>1gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>
<tr>
    <th>0592196453
        <th>2gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>


</TABLE>

<TABLE>      
<strong><em><h2 style="background color: black; color: white;">28/05/2023</h2></em></strong>
                                <TR>
                                    <TH>0593358550</TH>
                                    <th>1gb</th>
                                    <th>delivered</th>
                                </TR>
                                <tr>
                                <TH>0553546246</TH>
                                    <th>2gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                <TH>0245504923</TH>
                                <th>1gb</th>
                                <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0553621092</th>
                                    <th>1gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0557862830 </th>
                                    <th>9gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0546574493</th>
                                    <TH>6gb</TH>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0542323565</th>
                                    <th>1gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0543793149</th>
                                    <th>2gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0591713221 </th>
                                    <th>2gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0248425602</th>
                                    <th>1gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0248425602</th>
                                    <th>1gb</th>
                                    <th>burnt</th>
                                </tr>
                                <tr>
                                    <th>0591864439</th>
                                    <th>3gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0578930317</th>
                                    <th>4gb</th>
                                    <TH>delivered</TH>
                                </tr>
                                <tr>
                                    <th>0256646962</th>
                                    <th>1gb</th>
                                    <th>delivered</th>
                                </tr>
                                <tr>
                                    <th>0241980633
                                        <th>1gb
                                            <th>delivered

                                            </th>
                                        </th>
                                    </th>
                                </tr>
<tr>
    <th>0547017158
        <th>5gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>
<tr>
    <th>0267740138
        <th>5gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>
<tr>
    <th>0277933123
        <th>5gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>
<tr>
    <th>0546394370 
        <th>3gb
            <th>delivered
                
            </th>
        </th>
    </th>
</tr>
<tr>
    <th>0542794970
        <th>20gb
            <th>delivered
                
            </th>
        </th>
    </th>
</tr>
<tr>
    <th>0249523701
        <th>1gb
            <th>delivered
                
            </th>
        </th>
    </th>
</tr>
<tr>
    <th>0596138970
        <th>10gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>
<tr>
    <th>0599149962
        <th>1gb
            <th>delivered

            </th>
        </th>
    </th>
</tr>
                            </TAble>

                            </div>
                            </div>
                            <div class="card-body">
                                <p><strong>OUR MTN DATA BUNDLES DON'T WORK ON THESE SIMS</strong><br> ❌Transfer sim<br> ❌Turbonet sim&nbsp;<br> ❌Broadband Sim</p><p>No refund will be given if you place order to any of the stated categories above. Thank you&nbsp;</p>
                            
                                <p><strong>Do not hotspot other devices. This will make the data bundle last longer for use.</strong></p>
                            <p><strong>Do not buy *138# on MTN MSISDNs after the order is delivered. Customer is allowed to buy from *138# before order is placed.</strong></p></div>
                        </div>
                        </div>
<h3><h2> Click to<a href='https://app.formpress.org/form/view/8af3c985-3f71-4424-b2a4-8496acfd6b68' style="color: black;"> buy</a></body></html> <br>
<img src="index1.jpg" alt="airteltigo-2023-data plan" width="200px" height="120x"><img src="index2.jpg" alt="airteltigo-2023-data plan" width="200px" height="120x">
</center></body>
</html>