<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>request</title>
    <style>
    body{
    background-color: grey;
    color: white;
    }
</style>
</head>
<body>

<div class="card shadow mb-5 p-3">
                            <div class="title"><h1 style="color: white;"> CURRENT UPDATE</h1></div>
                            <div class="card-title">
                                <div class="alert alert-info">
                                    The following numbers have received their data bundles.
                                </div>
                            </div>
                            <table>
                                <tr>
                                    <th>Recipient number:</th>
                                    <th>Order</th>
                                    <th>Amount paid</th>
                                    <th></th>
                            <ol>
                                <li>
                                    <li>
                                        <li>
                                            <li>
                                                <li>
                                                    <li>

                                                    </li>
                                                </li>
                                            </li>
                                        </li>
                                    </li>
                                </li>
                            </ol>
                            <div class="card-body">
                                <p><strong>OUR DATA BUNDLES DON'T WORK ON THESE SIMS</strong><br> ❌Transfer sim<br> ❌Turbonet sim&nbsp;<br> ❌Broadband Sim</p><p>No refund will be given if you place order to any of the stated categories above. Thank you&nbsp;</p>
                            <p><strong>Do not hotspot other devices</strong></p>
                            <p><strong>Do not buy *138# on MTN MSISDNs after the order is delivered. Customer is allowed to buy from *138# before order is placed.</strong></p>
                            </div>
                        </div>
<h3><h2 style="color: white;"> Click to<a href='https://app.formpress.org/form/view/8af3c985-3f71-4424-b2a4-8496acfd6b68'> CHECK AND PLACE ORDER</a></body></html> <br>
<img src="index1.jpg" alt="airteltigo-2023-data plan" width="200px" height="120x"><img src="index2.jpg" alt="airteltigo-2023-data plan" width="200px" height="120x">
</body>
</html>