<?php

$tel=$_GET['tel'];
$password=$_GET['password'];

if ($tel=='558160752' & $password=='4835') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome OLIVA BLAY. <br>";
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";
    

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t' style='color: white;'>BUY</a> MTN Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</a>  AIRTELTIGO_GLO Data</body></html> <br>";
 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";

    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";    
    
}

elseif ($tel=='247263640' & $password=='0024') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ABRAHAM MAWUKO <br>";
    
    

    echo "<a href='https://forms.office.com/Pages/ResponsePage.aspx?id=DQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAMAAEXc0eFUOUlRMkZGUFhNMD
    MyT0FGOFNJSUxJNVNCWi4u'><html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";
    echo "BUY</a>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</a> AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}


elseif ($tel=='240644315' & $password=='TELLES315') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ASAMOAH JUSTICE <br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</a>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</a>  AIRTELTIGO_GLO Data</body></html> <br>";
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}



elseif ($tel=='541360281' & $password=='1058') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome Aryee Bismark <br>";
    
    

    echo "<html><head></head><style>bod y{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</a>  MTN Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A> AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}


elseif ($tel=='554374297' & $password=='1611') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome GEORGE ODURO <br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}

elseif ($tel=='240078930' & $password=='24EA') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ELIKPLIM ADABLA. <br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A> MTN Data</body></html> <br>";
    echo " <a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</a> AIRTELTIGO_GLO Data</body></html> <br>";
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}

elseif ($tel=='244844990' & $password=='AS212') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ABASS SEIDU. <br>";
    echo "PAY GH¢30.00 <br>";
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";
    echo "BUY <a href='https://forms.office.com/r/HV9FfC2uTG'> MTN </a> Data</body></html> <br>";
    echo "BUY <a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'> AIRTELTIGO_GLO </a>Data</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}
    elseif ($tel=='554680911' & $password=='1100') {
        #AGENT VALIDATION
        echo "<html><body><h1><h1>Welcome OFORI STEPHEN AMASAH. <br>";
        echo "<html><style>body{color: white;}</style><body><h4><em>Do you want to receive data 2 days after today? If yes, </em><a href='oliver.pay.0597438150.php'><em>Place</em></a>order.</body></html><br>";   

        echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

        echo " <a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A> MTNData</body></html> <br>";
        echo " <a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A> AIRTELTIGO_GLO Data</body></html> <br>";
        echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

        echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";      
    }
    
elseif ($tel=='247880702' & $password=='2024') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome GYIMAH FRANK<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo " <a href='https://forms.office.com/r/i1gVGh3c9t'> BUY</a> MTN Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY </a> AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
  

}


elseif ($tel=='241452634' & $password=='4302') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome DANIEL OPOKU KWAO<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo " <a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</a> MTN data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY </a> AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
  

}

elseif ($tel=='244104609' & $password=='09#02') {
    #AGENT VALIDATION 
    echo "<html><body><h1><h1>Welcome PHINEHAS OFORI ADOM<br>";
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";
    echo " <a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A> MTN data</a></body></html> <br>";
    echo " <a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</a> AIRTELTIGO_GLO>Data</body></html> <br>";
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
  

}

elseif ($tel=='541406137' & $password=='7345') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome DANIEL OKAI<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'> BUY </a> MTN data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY </a> AIRTELTIGO_GLO Data</body></html> <br>";
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
  

}




elseif ($tel=='548805048' & $password=='4854') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome SAMUEL ANTWI<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'> BUY </a> MTN data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY </a> AIRTELTIGO_GLO Data</body></html> <br>";
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
  

}


elseif ($tel=='249444405' & $password=='0502') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome SEIDU IDDRISU TANKO<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo " <a href='https://forms.office.com/r/i1gVGh3c9t'> BUY</a> MTN Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'> BUY </A> AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
  

}


elseif ($tel=='541591151' & $password=='1545') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome MOHAMMED ABANG-GOS <br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}



elseif ($tel=='594970291' & $password=='9195') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ENOCH TSORME-DZEBU<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}

elseif ($tel=='553226173' & $password=='7355') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome DANIELLA LARTEY<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}

elseif ($tel=='548522129' & $password=='2954') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome MORNY SELASE<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}


elseif ($tel=='597773321' & $password=='2159') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome CALEB WESLEY SAMAH<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";


    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}


elseif ($tel=='248354217' & $password=='1724') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ATANGA JOSEPH AKUGRE<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}




elseif ($tel=='244872577' & $password=='7724') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ADOKOH FRANK<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}



elseif ($tel=='554677439' & $password=='3955') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome EMMANUEL AWUKU<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}



elseif ($tel=='240253401' & $password=='0124') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome CHARLES OBENG<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
    
}



elseif ($tel=='547617127' & $password=='2754') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome FRANCIS ANSONG<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    




elseif ($tel=='554272235' & $password=='3555') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ESTHER AZONG<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    






elseif ($tel=='245738752' & $password=='5224') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome QUANDOH ATO KWAMENA<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    



elseif ($tel=='554874400' & $password=='0055') {
    #francisca rejected, george
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome FRANCISCA HEMANS<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    




elseif ($tel=='241970263' & $password=='6324') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome WISE ATARIYURE ATANGA<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    





elseif ($tel=='540420940' & $password=='4054') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome ERIC OPOKU MENSAH<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    





elseif ($tel=='557026222' & $password=='2255') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome JONATHAN CLOTTEY<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    




elseif ($tel=='550920000' & $password=='0055') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome EL ESSENTIALS<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    


elseif ($tel=='541776116' & $password=='1654') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome KWAW EWOOL<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    

//--------------------------------------------------------------------------------------------------------------------------------------------

elseif ($tel=='547224096' & $password=='9654') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome SILAS KWAKYE<br>";
    
    

    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    



elseif ($tel=='249168306' & $password=='6024') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome BENJAMIN BUABENG<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    



elseif ($tel=='547547090' & $password=='9054') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome EMMANUEL OWUSU<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    




elseif ($tel=='596532067' & $password=='6759') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome FAROUK TAHIRU<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    





elseif ($tel=='544439001' & $password=='0154') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome FOLLY JOHN AMAH<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    








elseif ($tel=='246715352' & $password=='5224') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome JOSEPH QAUYE<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    





elseif ($tel=='247344505' & $password=='0524') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome BEN KWAKU GELLI<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    







elseif ($tel=='531147417' & $password=='1753') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome PROTMISE KORWUTOR<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    






elseif ($tel=='559883859' & $password=='5955') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome AYISI DESMOND<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    




//--------------------------10th June-------------------------------------------------



elseif ($tel=='242951624' & $password=='2424') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome DESMOND DJABA<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    



elseif ($tel=='540795151' & $password=='5154') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome EBENEZER MARTEY<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    



elseif ($tel=='553798962' & $password=='6225') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome NORBERT EHWI KIZITO<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    



elseif ($tel=='554815412' & $password=='1255') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome SHAIBU ISSAH<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    



elseif ($tel=='598018937' & $password=='3759') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome MOSES DWAMENA<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    





elseif ($tel=='558064800' & $password=='0055') {
    #AGENT VALIDATION
    echo "<html><style>body{font-size: 20px}</style><body><center><h1><h1>Welcome THEOPHILUS MCKEOWN OKYERE<br>";
    
    
    
    echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";

    echo "<a href='https://forms.office.com/r/i1gVGh3c9t'>BUY</A>  MTN  Data</body></html> <br>";
    echo "<a href='https://forms.office.com/r/HV9FfC2uTG' style='color: white;'>BUY</A>  AIRTELTIGO_GLO Data</body></html> <br>"; 
    echo "<a href='mashups.php'><h3>Buy</a> airteltigo and glo mashups</h3><div><small>This offers is Non-Expiry</body></html> <br>";
    echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    
    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}    






else {
    echo "<html><body><h1><h1>feedback:</h1></h1></body></html>";
   echo  "<html><body><h1><h1>SORRY, NO AGENT HAS THIS CREDENTIALS. </h1></h1></body></html><div>";
   echo "<html><head></head><style>body{margin-left: 50px; background-color: grey; color: white;}</style>";
   echo " <html><body><a href='index.php'><h1><h2> LOGIN AGAIN</h1></h2></a></body></html>";
   echo  " <html><body> <img src='index1.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120px'></body></html>";

    echo " <html><body><img src='index2.jpg' alt='airteltigo-2023-Data plan' width='200px' height='120x'></body></html>";
}
?>
