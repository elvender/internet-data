<!DOCTYPE html><html lang="en"><head><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>closed</title><style>body{background-image:url(index.jpg);background-repeat: no-repeat;background-size: 100% 225%; color: white}</style></head><body>
<H1><H1><H1>MTN portal has been closed. <p><H2>AIRTELTIGO and GLO portal are opened.</H2><p><h5>All orders have been processed successfully.</H1></H1></H1></a>    <P>

<br>
    <caption>---Working Days and Working Time---</caption>
<TAble>
    <TR>
        <TH><u><b>NETWORK</b></u></TH>
        <th></th>
        <th></th>
        <TH><u><b> DAYS</TH>
        <TH></TH>
        
        <TH><u><b>WORKING TIME</TH>
    </TR>
    <TR>
        <TD>MTN</TD>
       <TD></TD>
       <TD></TD>
        <TD>MON-FRI</TD>
        <TD></TD>
        <TD>8:30AM-6:00PM</TD>
    </TR>
    <TR>
        <TD>GLO</TD>
       <TD></TD>
       <TD></TD>
        <TD>SUN-FRI</TD>
        <TD></TD>
        <TD>6AM-11PM</TD>
    </TR>
    <TR>
        <TD>AIRTELTIGO</TD>
       <TD></TD>
       <TD></TD>
        <TD>SUN-FRI</TD>
        <TD></TD>
        <TD>6AM-11PM</TD>
    </TR>

</TAble>
<Br>
Chat customer care center on <a href="http://wa.me/+233597438150">Whatsapp</a><p>
To become an agent you need to submit to <a href="http://wa.me/233597438150/">Whatsapp</a> <h1><u>Required details;</u></h1>    
<ol><li>Phone number</li>
<li>Full name</li></ol>
 
<marquee behavior="alternate" direction="right"><h1><h2>STARTING AT 8:20AM ON MONDAY</h2></h1></h1></marquee>

</body>

</html>