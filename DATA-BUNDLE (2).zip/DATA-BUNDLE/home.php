<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data bundle</title>
</head>
<style>
body{
    BACKGROUND-COLOR: grey;
    color: white;
}
</style>
<body>
    <center>
<script>
        function showInputs(){
            var x=document.getElementById("addMore");
            if(x.style.display==="none"){
                x.style.display="block";
            }else{
                x.style.display="none";
            }
        }
    </script>


<div class="card shadow mb-5 p-3">
                        <div class="title"><h1 style="color: white;"> Announcements</h1></div>
                        <div class="card-title">
                            <div class="alert alert-info">
                                ⚠️TAKE NOTE
                            </div>
                        </div>
                        <div class="card-body">
                            <p><strong><em>Pay with MTN MOBILE MONEY ONLY</em></strong></p>
                            <p><strong>do not repeat an order in the same hour.</strong></p>
                            <p><strong>OUR DATA BUNDLES DON'T WORK ON THESE SIMS</strong><br> ❌Transfer sim<br> ❌Turbonet sim&nbsp;<br> ❌Broadband Sim</p><p>No refund will be given if you place order to any of the stated categories above. Thank you&nbsp;</p>
                        
                            <p><strong>Do not hotspot other devices. This will make the data bundle last longer for use.</strong></p>
                        <p><strong>Do not buy *138# on MTN MSISDNs after the order is delivered. Customer is allowed to buy from *138# before order is placed.</strong></p></div>
                    </div>
<h3><h3 style="color: white;"> <a href='https://forms.office.com/r/M5StbLhgJS' style="color: white;">Buy</a> MTN data as a customer</body></html> <br>
<h3><h3 style="color: white;"> <a href='https://forms.office.com/r/Jmj1tQqdCy'style="color: white;">Buy</a> Airteltigo|glo data as a customer</body></html> <br>
<h3><h3 style="color: white;"> <a href='mashups.php' style="color: white;"><h3>Buy</a> airteltigo|glo minutes.</h3><div><small>This offers is Non-Expiry</body></html> <br>
<img src="index1.jpg" alt="airteltigo-2023-data plan" width="200px" height="120x">

<img src="index2.jpg" alt="airteltigo-2023-data plan" width="200px" height="120x">
<body>
<h4 style="margin-top: 5px; color: white;">
<a href="transaction-status-updated.php"><h2>Check</a> Check transaction status</h3>
</body>
<BR>
<form action="login.php" method="get">
<input type="tel" id="tel" placeholder="Phone" name="tel" minlength="9" maxlength="9" required="Enter agent number">
<input type="password" id="password" placeholder="password" name="password" minlength="2" maxlength="10"  required="Enter access password"><input type="submit" value="Login As Agent">
            
            </li>
        </ol>

</form>
<button><a href="https://paystack.com/pay/oliver-agent-registration-fee-"><h style="color: black;"> Register</button></center>



