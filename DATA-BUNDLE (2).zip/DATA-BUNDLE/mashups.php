<html>
<style>
    body{
        background-color: black;
        color: white;
        font-size: 25px;
        
    }
</style>
<body>
<Center>
    <form action="mailto:elvender1333@gmail.com" method="post" enctype="text/plain">
        
    <input type="tel" name="recipient" placeholder="Recipient phone number" id="recipient" maxlength="10" minlength="10" required><div>
    <small>Number must start with 0 E.g. 0261195199</small><p>
    <label>Airteltigo Glo Mashup No Expiry</label><div><select name="fuse" id="fuse">
<option>--Select an offer--</option>
<option> 110 minutes for GH&#8373;5.50</option>
<option >235 minutes for GH&#8373;11.00</option>
<option >300 minutes for GH&#8373;14.00</option>
<option >410 minutes for GH&#8373;19.00</option>
<option >535 minutes for GH&#8373;24.50</option>
<option >600 minutes for GH&#8373;28.00</option>
<option >900 minutes for GH&#8373;42.00</option>
<option >1010 minutes for GH&#8373;47.00</option>
<option >2035 minutes for GH&#8373;88.00</option>
<option> 2700 minutes for GH&#8373;119.0</option>
<option> 3600 minutes for GH&#8373;160.0</option>
</select><p>
    <p>pay with mtn mobile money only</p>
    Pay To 0597438150<p>
    <input type="TEXT" name="REF" placeholder="Transaction/Confirmation ID" id="Mobile_Money" Required>
<input type="submit" value="Submit email">
    </form>
    <div class="home" fas-fa="home">
    <a href="index.php"> <h2 style="color:white;"> Home/Refresh</h2></a></div>
</center>
</body>
</html>