<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data bundle</title>
</head>
<style>
    body{
        background-color:grey;
        margin-top:30px;
        color: white;
}
</style>

</body>
<center

<CEnter><SMALL><STRong><Em> <H1>MTN PORTAL IS OPENED. SEND ORDERS. </H1></Em></STRong></SMALL><p>
    8AM-7:15PM <P>
        <P>NO REFUND FOR YOUR MISTAKES. CLICK/TAP ON CLICK ME TO READ AND BUY</P>
    <img src="cl.webp" alt="closes at 7:10pm" width="50%" heigth="27%">
</CEnter>
<center><small><STRong><Em><H2>AIRTELTIGO DATA SERVICE IS AVAILABLE TILL 11PM</H2></em></strong></small>
<a href="home.php"><img src="clickme.svg" alt="" width="50%" heigth="27%"></a><div>
<caption>---Working Days and Working Time---</caption>
<TAble>
    <TR>
        <TH><u><b>NETWORK</b></u></TH>
        <th></th>
        <th></th>
        <TH><u><b> DAYS</TH>
        <TH></TH>
        
        <TH><u><b>WORKING TIME</TH>
    </TR>
    <TR>
        <TD>MTN</TD>
       <TD></TD>
       <TD></TD>
        <TD>MON-FRI</TD>
        <TD></TD>
        <TD>8A:00M-7:15PM</TD>
    </TR>
    <TR>
        <TD>MTN</TD>
       <TD></TD>
       <TD></TD>
        <TD>SAT</TD>
        <TD></TD>
        <TD>8:00AM-7:15PM</TD>
    </TR>
    <TR>
        <TD>MTN</TD>
       <TD></TD>
       <TD></TD>
        <TD>SUN</TD>
        <TD></TD>
        <TD>12:30PM-7:15PM</TD>
    </TR>
    <TR>
        <TD>GLO</TD>
       <TD></TD>
       <TD></TD>
        <TD>ALL DAYS</TD>
        <TD></TD>
        <TD>6AM-11PM</TD>
    </TR>
    <TR>
        <TD>AIRTELTIGO</TD>
       <TD></TD>
       <TD></TD>
        <TD>ALL DAYS</TD>
        <TD></TD>
        <TD>6AM-11PM</TD>
    </TR>

</TAble>
</div>
<Br>
Chat customer care center on <a href="http://wa.me/+233597438150">Whatsapp</a><p>
<h1>Register <a href="https://paystack.com/pay/oliver-agent-registration-fee-" style="color: white;" >here</a> to become an agent. </h1>   
<h2>You will be required to provide</h2>
<ol><li>Phone number</li>
<li>Full name</li>
<li>Ghana card and Voter ID number</li>
<LI>Voter ID number</LI></ol>
 <footer>
    Make sure the name on the sim matches the name on both ID before you submit.
 </footer>
 </center>
</body>
</html>


