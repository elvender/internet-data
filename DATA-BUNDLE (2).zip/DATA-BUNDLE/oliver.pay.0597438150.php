<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ORDER DATA</title>
</head>
<style>
    body{
        background-color:grey;
        color: white;
        font-weight: bold;
        
    }
</style>


<body><center>
<a style="color: white;">The orders below are delivered in the next two days. If you need some you can apply.</p>
<a style="color: white;"><a href="https://paystack.com/pay/oliver-airteltigo-glo-ishare">Airteltigo glo data</a><P>
<a style="color: white;"><a href="https://paystack.com/pay/mtnup2u">MTN internet data</a><p>
<a style="color: white;"><a href="coming-soon.php">Vodafone data</a>
    <br>
    <img src="gif.gif" alt="promo sticker" width="50%" heigth="27%"><p>
    
<footer>
    <small>
        <em><STRONG style="background-color:blue; color: white;">..TERMS: </STRONG> <a style="background-color:blue; color: white;">"This promotion is for registered agents only..."</em>
    </small>
</footer>
</body>
</html>
